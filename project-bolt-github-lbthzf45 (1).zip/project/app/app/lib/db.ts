// Database configuration removed - contact form now uses email-only functionality
// No database storage needed for simple contact form submissions
