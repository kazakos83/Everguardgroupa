var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__065n5sq._.js")
R.c("server/chunks/ssr/063z_next_dist_esm_build_templates_app-page_05f6qss.js")
R.c("server/chunks/ssr/[root-of-the-server]__030kerk._.js")
R.c("server/chunks/ssr/[root-of-the-server]__0neqx13._.js")
R.c("server/chunks/ssr/063z_next_dist_client_components_builtin_global-error_0v7xv1..js")
R.c("server/chunks/ssr/everguard-live-repo__next-internal_server_app__global-error_page_actions_0jp8dth.js")
R.m(59034)
module.exports=R.m(59034).exports
