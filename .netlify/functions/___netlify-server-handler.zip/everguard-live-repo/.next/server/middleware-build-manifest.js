globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/3upiClZ61hossIX3-7-x9/_buildManifest.js",
    "static/3upiClZ61hossIX3-7-x9/_ssgManifest.js",
    "static/3upiClZ61hossIX3-7-x9/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ly3v91yh_.o4.js",
    "static/chunks/051mfjat49yjw.js",
    "static/chunks/0d4qumfsodrzu.js",
    "static/chunks/0gg3vtzq3s4yc.js",
    "static/chunks/turbopack-0hp7ly~y~p82e.js"
  ]
};
