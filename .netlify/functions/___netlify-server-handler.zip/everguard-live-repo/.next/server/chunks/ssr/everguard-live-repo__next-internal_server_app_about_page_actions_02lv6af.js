module.exports=[90774,(a,b,c)=>{}];

//# sourceMappingURL=everguard-live-repo__next-internal_server_app_about_page_actions_02lv6af.js.map