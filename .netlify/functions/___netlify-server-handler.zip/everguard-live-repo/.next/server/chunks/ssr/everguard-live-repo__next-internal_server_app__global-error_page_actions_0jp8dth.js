module.exports=[64346,(a,b,c)=>{}];

//# sourceMappingURL=everguard-live-repo__next-internal_server_app__global-error_page_actions_0jp8dth.js.map